const loggingWebhook =
  "https://app.legions.bot/webhook/74413241-8fdd-4609-ba4c-95644d6c7dee";

module.exports = {
  loggingWebhook,
};
